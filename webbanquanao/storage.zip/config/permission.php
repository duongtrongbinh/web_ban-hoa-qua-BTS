<?php 

return [
    'access' => [
        'add-category' =>'add-category',
        'edit-category' =>'edit-category',
        'list-category' =>'list-category',
        'delete-category' =>'delete-category',
        'add-slide' =>'add-slide',
        'edit-slide' =>'edit-slide',
        'list-slide' =>'list-slide',
        'delete-slide' =>'delete-slide',
        'add-blog' =>'add-blog',
        'edit-blog' =>'edit-blog',
        'list-blog' =>'list-blog',
        'delete-blog' =>'delete-blog',
        'add-product' =>'add-product',
        'edit-product' =>'edit-product',
        'list-product' =>'list-product',
        'delete-product' =>'delete-product',
        'add-user' =>'add-user',
        'edit-user' =>'edit-user',
        'list-user' =>'list-user',
        'delete-user' =>'delete-user',
        'add-setting' =>'add-setting',
        'edit-setting' =>'edit-setting',
        'list-setting' =>'list-setting',
        'delete-setting' =>'delete-setting'
    ]
];