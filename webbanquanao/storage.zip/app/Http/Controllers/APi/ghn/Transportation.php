<?php

namespace App\Http\Controllers\APi\ghn;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Transportation extends Controller
{
    
}
