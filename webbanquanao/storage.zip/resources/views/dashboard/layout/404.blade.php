<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>403</title>
</head>
<body>
    <div class="container">
        <img width="100%" height="100%" src="https://media.istockphoto.com/id/860109848/vector/error-404-sorry-the-page-not-found-back-to-home.jpg?s=612x612&w=0&k=20&c=p3tzNC8OnO_7dqZNWpcqJZVbixzWbu3wbtmOpdGZN3s=" alt="">
    </div>
</body>
</html>

