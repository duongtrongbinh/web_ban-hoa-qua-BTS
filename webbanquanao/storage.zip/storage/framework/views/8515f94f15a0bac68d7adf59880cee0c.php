<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('admin/assets/js/deleteAll/delete.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Dashboard</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('/dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item active">Blog</li>
      </ol>
    </nav>
</div>


<div class="card">
    <div class="card-body">
      <h5 class="card-title">List Blog</h5>
      <!-- Table with stripped rows -->
      <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Image Blog</th>
            <th scope="col">User</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody> 
          <?php $count=0; ?>
          <?php $__currentLoopData = $listBlog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $count++; ?>
         
          <tr>
            <th scope="row"><?php echo e($count); ?></th>
            <td><h3><?php echo e($item->title); ?></h3></td>
            <td><img width="200px" height="auto" src="<?php echo e($item->code_image); ?>" alt="<?php echo e($item->name_image); ?>"></td>
            <td><?php echo e($item->userB->name); ?></td>
            <td class="d-flex ">
                <a href="<?php echo e(route('edit_blog',[$item->id])); ?>" class="btn btn-success" style="margin-right: 10px">Edit</a>
                <a data-url="<?php echo e(route('delete_blog',[$item->id])); ?>" class="btn btn-warning deleteBlog">Delete</a>
            </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
        </tbody>
      </table>
      <!-- End Table with stripped rows -->

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\my-app\webbanquanao\resources\views/dashboard/admin/blogs/list.blade.php ENDPATH**/ ?>