<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('admin/assets/js/deleteAll/delete.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Dashboard</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('/dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item active">Slide</li>
      </ol>
    </nav>
</div>


<div class="card">
    <div class="card-body">
      <h5 class="card-title">List slide</h5>
      <div class="d-flex justify-content-end mt-2 mb-2">
        <a href="<?php echo e(route('form_add_slide')); ?>" class="btn btn-primary mb-3 bt-3" >
            Add Slide
          </a>
        </div>
      <!-- Table with stripped rows -->
      <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Description</th>
            <th scope="col">Image Slide</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody> 
          <?php $count=0; ?>
          <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $count++; ?>
         
          <tr>
            <th scope="row"><?php echo e($count); ?></th>
            <td><h1><?php echo e($item->title); ?></h1></td>
            <td><p><?php echo e($item->desc); ?></p></td>
            <td><img width="150px" height="auto" src="<?php echo e($item->code_image); ?>" alt="<?php echo e($item->name_image); ?>"></td>
            <td>
                <a href="<?php echo e(route('edit_slide',[$item->id])); ?>" class="btn btn-success">Edit</a>
                <a data-url="<?php echo e(route('delete_slide',[$item->id])); ?>" class="btn btn-warning deleteSlide">Delete</a>
            </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
        </tbody>
      </table>
      <!-- End Table with stripped rows -->

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\my-app\webbanquanao\resources\views/dashboard/admin/slides/list.blade.php ENDPATH**/ ?>