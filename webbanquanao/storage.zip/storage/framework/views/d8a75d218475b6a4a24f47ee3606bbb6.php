
<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('admin/assets/js/deleteAll/delete.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Dashboard</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('/dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item active">Orders</li>
      </ol>
    </nav>
</div>

<div class="col-xl-12">
    <div class="card">
      <div class="card-body pt-3">
        <!-- Bordered Tabs -->
        <ul class="nav nav-tabs nav-tabs-bordered">
          <li class="nav-item">
            <button
              class="nav-link"
              data-bs-toggle="tab"
              data-bs-target="#profile-orders"
            >
              Đơn hàng (<?php echo e(count($order['status1'])); ?>)

            </button>
          </li>

          <li class="nav-item">
            <button
              class="nav-link"
              data-bs-toggle="tab"
              data-bs-target="#profile-order-success"
            >
              Đã hoàn tất (<?php echo e(count($order['status2'])); ?>)
            </button>
          </li>

          <li class="nav-item">
            <button
              class="nav-link"
              data-bs-toggle="tab"
              data-bs-target="#profile-order-cancel"
            >
              Đơn hủy (<?php echo e(count($order['status4'])); ?>)
            </button>
          </li>

          <li class="nav-item">
            <button
              class="nav-link"
              data-bs-toggle="tab"
              data-bs-target="#profile-order-return"
            >
              Trả hàng (<?php echo e(count($order['status3'])); ?>)
            </button>
          </li>

        </ul>
        <div class="tab-content pt-2">
          <div class="tab-pane fade pt-3" id="profile-orders">
                <!-- Profile order Form -->
                    <div class="card">
                        <div class="card-body">
                        <h5 class="card-title">Đơn hàng</h5>

                        <!-- Table with stripped rows -->
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Mã đơn</th>
                                <th scope="col">Bên nhận</th>
                                <th scope="col">Tổng tiền</th>
                                <th scope="col">Tiền vận chuyển</th>
                                <th scope="col">Tùy chọn thanh toán</th>
                                <th scope="col">Hình thức thanh toán</th>
                                <th scope="col">Trạng thái</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody> 
                            <?php $__currentLoopData = $order['status1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                        <td><?php echo e($item->code); ?></td>
                                        <td>
                                            <div class="container">
                                                <h6><?php echo e($item->name); ?></h6>
                                                <h6><?php echo e($item->phone); ?></h6>
                                                <h6><?php echo e($item->address); ?></h6>
                                                <h6>ngày tạo:<?php echo e($item->created_at->format('Y-m-d')); ?></h6>
                                            </div>
                                        </td>
                                        <td><?php echo e(number_format($item->total, 0, ',', '.')); ?> VND</td>
                                        <td><?php echo e(number_format($item->moneyship, 0, ',', '.')); ?> VND</td>
                                        <td><?php echo e($item->payment_id == 1 ? "Đã thanh toán" : "chưa thanh toán"); ?></td>
                                        <td><?php echo e($item->payment_id == 1 ? "Thanh toán vnpay" : "Thanh toán khi nhận hàng"); ?></td>
                                        <?php $__currentLoopData = $statusO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $statusLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($index == $item->status): ?>
                                                <td> <?php echo e($statusLabel); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td>
                                        
                                            <a  href="<?php echo e(route('detail_order',[$item->id])); ?>" class="btn btn-success" selected>Detail</a>
                                        
                                        
                                            
                                        
                                        </td>
                                    </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                        </div>
                    </div>
                <!-- End Profile order Form -->
          </div>

          <div class="tab-pane fade pt-3" id="profile-order-success">
            <!-- profile success Form -->
            <div class="card">
                <div class="card-body">
                <h5 class="card-title">Đơn hàng</h5>

                <!-- Table with stripped rows -->
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Mã đơn</th>
                        <th scope="col">Bên nhận</th>
                        <th scope="col">Tổng tiền</th>
                        <th scope="col">Tiền vận chuyển</th>
                        <th scope="col">Tùy chọn thanh toán</th>
                        <th scope="col">Hình thức thanh toán</th>
                        <th scope="col">Trạng thái</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody> 
                    <?php $__currentLoopData = $order['status2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <tr>
                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                <td><?php echo e($item->code); ?></td>
                                <td>
                                    <div class="container">
                                        <h6><?php echo e($item->name); ?></h6>
                                        <h6><?php echo e($item->phone); ?></h6>
                                        <h6><?php echo e($item->address); ?></h6>
                                        <h6>ngày tạo:<?php echo e($item->created_at->format('Y-m-d')); ?></h6>
                                    </div>
                                </td>
                                <td><?php echo e(number_format($item->total, 0, ',', '.')); ?> VND</td>
                                <td><?php echo e(number_format($item->moneyship, 0, ',', '.')); ?> VND</td>
                                <td><?php echo e($item->payment_id == 1 ? "Đã thanh toán" : "chưa thanh toán"); ?></td>
                                <td><?php echo e($item->payment_id == 1 ? "Thanh toán vnpay" : "Thanh toán khi nhận hàng"); ?></td>
                                <?php $__currentLoopData = $statusO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $statusLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($index == $item->status): ?>
                                        <td> <?php echo e($statusLabel); ?></td>
                                    <?php endif; ?>
                                <td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                
                                    <a  href="<?php echo e(route('detail_order',[$item->id])); ?>" class="btn btn-success" selected>Detail</a>
                                
                                
                                    
                                
                                </td>
                            </tr>
 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </tbody>
                </table>
                <!-- End Table with stripped rows -->

                </div>
            </div>
            <!-- End profile success Form -->
          </div>

          <div class="tab-pane fade pt-3" id="profile-order-cancel">
            <!-- profile cancel Form -->
            <div class="card">
                <div class="card-body">
                <h5 class="card-title">Đơn hàng</h5>

                <!-- Table with stripped rows -->
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Mã đơn</th>
                        <th scope="col">Bên nhận</th>
                        <th scope="col">Tổng tiền</th>
                        <th scope="col">Tiền vận chuyển</th>
                        <th scope="col">Tùy chọn thanh toán</th>
                        <th scope="col">Hình thức thanh toán</th>
                        <th scope="col">Trạng thái</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody> 
                    <?php $__currentLoopData = $order['status4']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                <td><?php echo e($item->code); ?></td>
                                <td>
                                    <div class="container">
                                        <h6><?php echo e($item->name); ?></h6>
                                        <h6><?php echo e($item->phone); ?></h6>
                                        <h6><?php echo e($item->address); ?></h6>
                                        <h6>ngày tạo:<?php echo e($item->created_at->format('Y-m-d')); ?></h6>
                                    </div>
                                </td>
                                <td><?php echo e(number_format($item->total, 0, ',', '.')); ?> VND</td>
                                <td><?php echo e(number_format($item->moneyship, 0, ',', '.')); ?> VND</td>
                                <td><?php echo e($item->payment_id == 1 ? "Đã thanh toán" : "chưa thanh toán"); ?></td>
                                <td><?php echo e($item->payment_id == 1 ? "Thanh toán vnpay" : "Thanh toán khi nhận hàng"); ?></td>
                                <?php $__currentLoopData = $statusO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $statusLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($index == $item->status): ?>
                                        <td> <?php echo e($statusLabel); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                
                                    <a  href="<?php echo e(route('detail_order',[$item->id])); ?>" class="btn btn-success" selected>Detail</a>
                                
                                
                                    
                                
                                </td>
                            </tr>
    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                <!-- End Table with stripped rows -->

                </div>
            </div>
            <!-- End profile cancel Form -->

            
          </div>

          <div class="tab-pane fade pt-3" id="profile-order-return">
            <!-- profile success Form -->
            <div class="card">
                <div class="card-body">
                <h5 class="card-title">Đơn hàng</h5>

                <!-- Table with stripped rows -->
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Mã đơn</th>
                        <th scope="col">Bên nhận</th>
                        <th scope="col">Tổng tiền</th>
                        <th scope="col">Tiền vận chuyển</th>
                        <th scope="col">Tùy chọn thanh toán</th>
                        <th scope="col">Hình thức thanh toán</th>
                        <th scope="col">Trạng thái</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody> 
                    <?php $__currentLoopData = $order['status3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <tr>
                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                <td><?php echo e($item->code); ?></td>
                                <td>
                                    <div class="container">
                                        <h6><?php echo e($item->name); ?></h6>
                                        <h6><?php echo e($item->phone); ?></h6>
                                        <h6><?php echo e($item->address); ?></h6>
                                        <h6>ngày tạo:<?php echo e($item->created_at->format('Y-m-d')); ?></h6>
                                    </div>
                                </td>
                                <td><?php echo e(number_format($item->total, 0, ',', '.')); ?> VND</td>
                                <td><?php echo e(number_format($item->moneyship, 0, ',', '.')); ?> VND</td>
                                <td><?php echo e($item->payment_id == 1 ? "Đã thanh toán" : "chưa thanh toán"); ?></td>
                                <td><?php echo e($item->payment_id == 1 ? "Thanh toán vnpay" : "Thanh toán khi nhận hàng"); ?></td>
                                <?php $__currentLoopData = $statusO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $statusLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($index == $item->status): ?>
                                        <td> <?php echo e($statusLabel); ?></td>
                                    <?php endif; ?>
                                <td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                
                                    <a  href="<?php echo e(route('detail_order',[$item->id])); ?>" class="btn btn-success" selected>Detail</a>
                                
                                
                                    
                                
                                </td>
                            </tr>
 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </tbody>
                </table>
                <!-- End Table with stripped rows -->

                </div>
            </div>
            <!-- End profile success Form -->
          </div>
        </div>
        <!-- End Bordered Tabs -->
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\my-app\webbanquanao\resources\views/dashboard/admin/bills/list.blade.php ENDPATH**/ ?>