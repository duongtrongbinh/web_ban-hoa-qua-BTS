<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/select2/index.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('admin/assets/vendor/select2/index.min.js')); ?>"></script>
<script>
    $('.select2_per').select2({
        'placeholder': "Vui lòng chọn vai trò."
    });
</script> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Dashboard</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('/dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item">List Nhân viên</li>
        <li class="breadcrumb-item active">Update Nhân viên</li>
      </ol>
    </nav>
</div>

<form action="<?php echo e(route('update_user',[$user->id])); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-6">
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="name" class="form-control mt-2" placeholder="Vui lòng nhập họ và tên của bạn." value="<?php echo e($user->name); ?>">
              </div>
              <div class="form-group mt-3">
                  <label>Email</label>
                  <input type="email" name="email" class="form-control mt-2" placeholder="Vui lòng nhập email của bạn." value="<?php echo e($user->email); ?>">

              </div>
        </div>
        <div class="col-6 ">
            <div class="form-group">
                <label>Address</label>
                <input type="text" name="address" class="form-control mt-2" placeholder="Vui lòng nhập địa chỉ của bạn." value="<?php echo e($user->address); ?>">
              </div>
            
            <div class="form-group mt-3">
                    <label>Phone</label>
                    <input type="text" name="phone" class="form-control mt-2" placeholder="Vui lòng nhập số điện thoại bạn." value="<?php echo e($user->phone); ?>">
                </div>
            
        </div>
        <div class="col-12">
            <div class="form-group mt-3">
                <label>Giới thiệu bản thân</label>
                <textarea type="text" name="desc" class="form-control mt-2" placeholder="Vui lòng giới thiệu bản thân bạn."><?php echo e($user->desc); ?></textarea>
              </div>
        </div>

        <div class="col-6">
            <div class="form-group mt-3">
                <label>Nhập ảnh đại diện</label>
                <input type="file" name="image_avatar" class="form-control mt-2">
            </div>
        </div>
        <div class="col-6">
            <div class="form-group mt-3 text-center">
                <img src="<?php echo e($user->image_avatar); ?>" alt="<?php echo e($user->name_avatar); ?>" width="300px" height="250px">
            </div>
        </div>
        <div class="col-12 mt-3">

            <div class="form-group">
                <label>Vai trò</label>
                <select name="role[]" multiple class="form-control mt-2 select2_per" >
                    <option value=""></option>
                    <?php $__currentLoopData = $listRole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e($roleOfUser->contains('id',$item->id) ? "selected" : ""); ?>><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-12 text-center mt-3">
            <button type="submit" class="btn btn-primary">Update User</button>
        </div>
    </div>


</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\my-app\webbanquanao\resources\views/dashboard/permissions/role/update.blade.php ENDPATH**/ ?>