<?php $__env->startSection('content'); ?>
<div class="mb-5">
    <div class="pagetitle">
      <h1>Setting</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Setting</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
</div>

    <section class="section contact">

      <div class="row gy-4">

          <div class="row">
            <div class="col-lg-6">
                <div class="info-box card">
                  <i class="bi bi-badge-cc"></i>
                  <h3>Name Company</h3>
                  <p><?php echo e($setting->name_company); ?></p>
                </div>
              </div>
            <div class="col-lg-6">
              <div class="info-box card">
                <i class="bi bi-geo-alt"></i>
                <h3>Address</h3>
                <p><?php echo e($setting->address); ?></p>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="info-box card">
                <i class="bi bi-telephone"></i>
                <h3>Phone Company</h3>
                <p><?php echo e($setting->phone); ?><br><?php echo e($setting->phone2); ?></p>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="info-box card mb-2">
                <i class="bi bi-envelope"></i>
                <h3>Email Us</h3>
                <p><?php echo e($setting->email); ?></p>
                <br>
              </div>
            </div>
          </div>
            <div class="text-center">
                <a href="<?php echo e(route('edit_setting',[1])); ?>"  class="div btn btn-primary">Edit</a href="">
            </div>
        </div>


    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\my-app\webbanquanao\resources\views/dashboard/admin/settings/list.blade.php ENDPATH**/ ?>