<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/datatable/index.min.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <div class="d-flex" style="justify-content: space-between">
      <h1>Dashboard</h1>
      <div>
        <a class="btn btn-outline-success pr-3" href="<?php echo e(route('export_list_product')); ?>">Import</a>  
        <a class="btn btn-outline-success pr-3" href="<?php echo e(route('export_list_product')); ?>">Export</a>  
      </div>
    </div>
    <nav >
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('/dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item">Product</li>
        <li class="breadcrumb-item active">List Product</li>
      </ol>
    </nav>
  </div>



<div class="card">
    <div class="card-body mt-5">

      <!-- Table with stripped rows -->
      <table class="table table-striped datatableProduct" >
        <thead>
          <tr>
            <th scope="col">#</th>
            <th>Code</th>
            <th>Name</th>
            <th>Category</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        </tbody>
      </table>
      <!-- End Table with stripped rows -->

    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('admin/assets/vendor/datatable/index.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('admin/assets/js/deleteAll/delete.js')); ?>"></script>
<script>
  $(function () {
    // $.fn.dataTable.ext.errMode = 'throw';
    let table = $('.datatableProduct').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?php echo e(route("list_product")); ?>',
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
            {data: 'code', name: 'code'},
            {data: 'name', name: 'name'},
            {data: 'category_name', name: 'category'},
            {data: 'quantity', name: 'quantity'},
            {data: 'price', name: 'price'},
            {
                data: 'action', 
                name: 'action', 
                orderable: true, 
                searchable: true
            },
        ]
    });
    
  });
</script>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('dashboard.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\my-app\webbanquanao\resources\views/dashboard/admin/products/list.blade.php ENDPATH**/ ?>