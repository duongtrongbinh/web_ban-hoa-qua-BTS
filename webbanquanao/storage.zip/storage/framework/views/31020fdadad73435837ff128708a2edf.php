<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('add_categories')); ?>">  
    <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="" class="form-lable mb-2">Name</label>
            <input type="text" name="name" class="form-control" placeholder="Nhập name ...">
        </div>
        <div class="form-group mt-2">
            <label for="" class="form-lable mb-2">Select Parent Folder</label>
            <select class="form-select" name="parent_id">
                <option value='0' selected>Choose...</option>
                    {<?php echo $htmlSelect; ?>}
              </select>
        </div>
      <div class="d-flex text-center mt-5 ">
        <button type="submit" class="btn btn-primary">Add</button>
        <button type="reset" class="btn btn-success">Reset</button>
      </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\my-app\webbanquanao\resources\views/dashboard/admin/categories/add.blade.php ENDPATH**/ ?>