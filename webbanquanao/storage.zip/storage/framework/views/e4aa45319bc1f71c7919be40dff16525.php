
<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('admin/assets/js/deleteAll/delete.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Dashboard</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('/dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item active">Order Detail</li>
      </ol>
    </nav>
</div>

                <div class="card ml-5">

                    <div class="card-body mt-5">
                            
                            <h3 class="modal-title">Chi tiết đơn hàng</h3>


                            <div class="row">
                            <div class="col-lg-3 col-md-4 label">
                                Mã đơn
                            </div>
                            <div class="col-lg-9 col-md-8">
                                <?php echo e($oneOrder->code); ?>

                            </div>
                            </div>

                            <div class="row">
                            <div class="col-lg-3 col-md-4 label">
                                Ngày mua hàng:
                            </div>
                            <div class="col-lg-9 col-md-8">
                                <?php echo e($oneOrder->created_at); ?>

                            </div>
                            </div>

                            <div class="row">
                            <div class="col-lg-3 col-md-4 label">
                                Người nhận:
                            </div>
                            <div class="col-lg-9 col-md-8">
                                <?php echo e($oneOrder->name); ?>

                            </div>
                            </div>

                            <div class="row">
                            <div class="col-lg-3 col-md-4 label">
                                Số điện thoại:
                            </div>
                            <div class="col-lg-9 col-md-8">
                                <?php echo e($oneOrder->phone); ?>

                            </div>
                            </div>

                            <div class="row">
                            <div class="col-lg-3 col-md-4 label">
                                Địa chỉ:
                            </div>
                            <div class="col-lg-9 col-md-8">
                                <?php echo e($oneOrder->address); ?>

                            </div>
                            </div>

                            <div class="row">
                            <div class="col-lg-3 col-md-4 label">
                                Thanh toán:
                            </div>
                            <div class="col-lg-9 col-md-8">
                                <?php echo e($oneOrder->payment_id == 1 ? "Thanh toán vnpay" : "Thanh toán khi nhận hàng"); ?>

                            </div>
                            </div>

                            <div class="row">
                            <div class="col-lg-3 col-md-4 label">
                                Trạng thái:
                            </div>
                            <div class="col-lg-9 col-md-8">
                                <?php $__currentLoopData = $statusO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $statusLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($index == $oneOrder->status): ?>
                                    <?php echo e($statusLabel); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            </div>
                        

                        <h3 class="mt-3 mb-3">
                            Sản phẩm (<?php echo e(count($oneOrder->order_detail)); ?>)
                            </h3>
               
                        <?php $__currentLoopData = $oneOrder->order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-around">
                                <div class="label"><?php echo e($detail->product->name); ?></div>
                                <div class=" label"><?php echo e($detail->quantity); ?></div>
                                <div class="label"><?php echo e(number_format(($detail->quantity * $detail->price), 0, ',', '.')); ?>  VND</div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <h3 class="mt-3 mb-3">
                            Vận chuyển
                            </h3>

                        <?php
                            $result = array_slice($statusO, 0, $oneOrder->status);
                        ?>
                        <div class="d-flex">
                            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h5><?php echo e($item); ?></h5>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                </div>

                

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\my-app\webbanquanao\resources\views/dashboard/admin/bills/detail.blade.php ENDPATH**/ ?>