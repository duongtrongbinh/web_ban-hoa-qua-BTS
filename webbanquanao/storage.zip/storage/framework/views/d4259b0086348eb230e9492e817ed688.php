<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Dashboard</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('/dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item active">Add Blog</li>
      </ol>
    </nav>
  </div>
<div class="container-fuild">
  <div class="row">
    <form method="POST" action="<?php echo e(route('add_blog')); ?>" enctype="multipart/form-data">  
      <?php echo csrf_field(); ?>
        <div class="modal-body">
        <div class="form-group mt-3">
            <label for="" class="form-lable mb-2">Title</label>
            <input type="text" name="title" class="form-control" placeholder="Nhập title ..." >
        </div>

        <div class="form-group mt-3">
            <label class="form-lable mb-2">Image</label>
            <input type="file" name="code" class="form-control">
        </div>

          <div class="form-group col mt-2">
            <label for="" class="form-lable mb-2">Content</label>
            <textarea class="form-control my-editor-tinymce4" name="content" placeholder="Nhập content ..."></textarea>
          </div>

        </div>
        <div class="mt-5 text-center">
          <button type="submit" class="btn btn-primary">Add</button>
          <button type="reset" class="btn btn-outline-warning">Reset</button>
        </div>
  </form>
  </div>
</div>
<?php $__env->startSection('js'); ?>

<script src="<?php echo e(asset('admin/assets/js/product/addProduct.js')); ?>"></script>
<script src="/path-to-your-tinymce/tinymce.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('dashboard.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\my-app\webbanquanao\resources\views/dashboard/admin/blogs/add.blade.php ENDPATH**/ ?>